Please refer to the WinFellow User Manual for instructions on how to use TransROM and TransDisk.

These are the same that are available in the UAE-distribution.


TransDisk authors are:

Copyright 1995-97 Bernd Schmidt, Marcus Sundberg, Stefan Ropke,
                  Rodney Hester, Joanne Dow


TransROM authors are:

Copyright 1995,1996 Bernd Schmidt, Marcus Sundberg, Stefan Ropke,
                    Rodney Hester

